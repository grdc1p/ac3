let frase = "Memphis Depay é Brabo";
let palavras = frase.split(" ");
let contador = 0;

palavras.forEach(() => {
contador++;
});

console.log(contador);
