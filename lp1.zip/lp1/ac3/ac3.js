//Questao 1
let produtos = ["Celuar", "Mouse", "Monitor", "Notebbok", "Impressora", 
"Teclado", "Telveisão", "Fone", "Webcam", "HD Externo"];
produtos[0] = "Celular"
produtos[3] = "Monitor"
produtos[6] = "Televisão"
 
console.log(produtos)

//questao 2




let numerosAleatorios = Math.floor(Math.random() * 10  );
let numeros = [2, 5, 8, 13, 16, 21];
let newArray= []
 numeros.forEach(function(numeros)
 {
if (numeros % 2 === 0){
    numeros * numerosAleatorios;
    newArray.push(numeros)
    } else {newArray.push(numeros)}

})
console.log(newArray)




// Questao 3
 let numeros3 = [1.2, 3.7, 4.5, 6.1, 8.9];

 let numerosCorretos = [];

 numeros3.forEach(function(numeros){

    Math.round(numeros)

    numerosCorretos.push(numeros)
 }
)

// Questao 4
const nome = prompt ("Escreva seu nome completo")

let palavras = frase.split(" ");
let contador = 0;

palavras.forEach(function (){
if(palavras != " " ){
contador++

}}
)

// Questao 5
let newNumeros = [1,2,3];
let numerosIndicados = [4,5,6];
newNUmeros,forEach(function(numeros) {
    numerosIndicados.unshift(numeros)
})
console.log(numerosIndicados)
